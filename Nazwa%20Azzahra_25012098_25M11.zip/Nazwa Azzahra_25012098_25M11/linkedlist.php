<?php
session_start();
if (!isset($_SESSION['list_data'])) $_SESSION['list_data'] = ["Node A", "Node B", "Node C"];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $value = trim($_POST['value'] ?? '');
    $index = isset($_POST['index']) ? (int)$_POST['index'] : -1;

    if ($action === 'add' && $value !== '') $_SESSION['list_data'][] = $value;
    if ($action === 'delete' && isset($_SESSION['list_data'][$index])) array_splice($_SESSION['list_data'], $index, 1);
    if ($action === 'reset') $_SESSION['list_data'] = ["Node A", "Node B", "Node C"];
    header("Location: linkedlist.php"); exit;
}
$data = $_SESSION['list_data'];
?>
<!DOCTYPE html>
<html lang="id"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Linked List - Struktur Data</title><link rel="stylesheet" href="style.css"></head>
<body>
<header><div class="container"><h1>Linked List</h1><p>Implementasi Struktur Data Linear</p></div></header>
<main class="container">
<a class="back" href="index.php">← Kembali ke Beranda</a>
<section class="panel">
<h2>Simulasi Linked List</h2>
<p>Linked List terdiri dari node. Setiap node menyimpan data dan hubungan (link) menuju node berikutnya.</p>
<div class="forms">
<form method="post"><input type="hidden" name="action" value="add"><input name="value" placeholder="Data node baru" required><button>Tambah Node</button></form>
<form method="post"><input type="hidden" name="action" value="delete"><input type="number" name="index" min="0" placeholder="Indeks node" required><button class="danger">Hapus Node</button></form>
<form method="post"><input type="hidden" name="action" value="reset"><button class="secondary">Reset</button></form>
</div>
<div class="linked-row">
<?php foreach ($data as $i => $item): ?>
<div class="node-wrap">
<div class="node"><small>Node <?= $i + 1 ?></small><strong><?= htmlspecialchars($item) ?></strong><span>next →</span></div>
<?php if ($i < count($data)-1): ?><div class="arrow">→</div><?php endif; ?>
</div>
<?php endforeach; ?>
<div class="null-node">NULL</div>
</div>
<h3>Konsep</h3><p>Node pertama disebut <b>head</b>. Setiap node terhubung ke node berikutnya. Node terakhir menunjuk ke <b>NULL</b>.</p>
</section>
</main><footer>Linked List • Nazwa Azzahra • 25012098 • 25M11</footer>
</body></html>