# Project Struktur Data Linear

**Nama:** Nazwa Azzahra  
**NIM:** 25012098  
**Kelas:** 25M11  

## Deskripsi
Project PHP ini mengimplementasikan tiga struktur data linear:
1. Array
2. Linked List
3. Stack

Setiap halaman dibuat interaktif agar pengguna dapat menambah, menghapus, mencari, atau memanipulasi data dan melihat perubahan struktur data secara langsung.

## Struktur Folder
```text
Nazwa Azzahra_25012098_25M11/
├── index.php
├── array.php
├── linkedlist.php
├── stack.php
├── style.css
└── README.md
```

## Cara Menjalankan
1. Install XAMPP.
2. Salin folder project ke `C:\xampp\htdocs\`.
3. Jalankan **Apache** dari XAMPP.
4. Buka:
   `http://localhost/Nazwa%20Azzahra_25012098_25M11/`
5. Pilih halaman Array, Linked List, atau Stack.

## Fitur
- **Array:** tambah, hapus berdasarkan indeks, cari, dan reset.
- **Linked List:** tambah node, hapus node berdasarkan indeks, dan reset.
- **Stack:** Push, Pop, dan Reset dengan konsep LIFO.
