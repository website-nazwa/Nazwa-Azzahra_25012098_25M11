<?php
session_start();
if (!isset($_SESSION['stack_data'])) $_SESSION['stack_data'] = ["Buku 1", "Buku 2", "Buku 3"];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $value = trim($_POST['value'] ?? '');

    if ($action === 'push' && $value !== '') $_SESSION['stack_data'][] = $value;
    if ($action === 'pop' && count($_SESSION['stack_data']) > 0) array_pop($_SESSION['stack_data']);
    if ($action === 'reset') $_SESSION['stack_data'] = ["Buku 1", "Buku 2", "Buku 3"];
    header("Location: stack.php"); exit;
}
$data = $_SESSION['stack_data'];
?>
<!DOCTYPE html>
<html lang="id"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Stack - Struktur Data</title><link rel="stylesheet" href="style.css"></head>
<body>
<header><div class="container"><h1>Stack</h1><p>Implementasi Struktur Data Linear</p></div></header>
<main class="container">
<a class="back" href="index.php">← Kembali ke Beranda</a>
<section class="panel">
<h2>Simulasi Stack</h2>
<p>Stack menggunakan prinsip <b>LIFO (Last In, First Out)</b>: data yang terakhir masuk akan keluar terlebih dahulu.</p>
<div class="forms">
<form method="post"><input type="hidden" name="action" value="push"><input name="value" placeholder="Data baru" required><button>Push</button></form>
<form method="post"><input type="hidden" name="action" value="pop"><button class="danger">Pop</button></form>
<form method="post"><input type="hidden" name="action" value="reset"><button class="secondary">Reset</button></form>
</div>
<div class="stack-area">
<div class="stack">
<?php if (!$data): ?><div class="empty">Stack kosong</div><?php endif; ?>
<?php foreach (array_reverse($data) as $i => $item): ?>
<div class="stack-item"><?= htmlspecialchars($item) ?><?= $i === 0 ? ' ← TOP' : '' ?></div>
<?php endforeach; ?>
<div class="stack-base">BOTTOM</div>
</div>
<div class="explain"><b>TOP</b> adalah posisi data yang akan dikeluarkan saat tombol <b>Pop</b> ditekan.</div>
</div>
<h3>Konsep</h3><p><b>Push</b> menambahkan data ke bagian TOP. <b>Pop</b> menghapus data paling atas. Karena LIFO, elemen terakhir yang masuk menjadi elemen pertama yang keluar.</p>
</section>
</main><footer>Stack • Nazwa Azzahra • 25012098 • 25M11</footer>
</body></html>