<?php
session_start();
if (!isset($_SESSION['array_data'])) $_SESSION['array_data'] = ["Apel", "Jeruk", "Mangga"];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $value = trim($_POST['value'] ?? '');
    $index = isset($_POST['index']) ? (int)$_POST['index'] : -1;

    if ($action === 'add' && $value !== '') $_SESSION['array_data'][] = $value;
    if ($action === 'delete' && isset($_SESSION['array_data'][$index])) array_splice($_SESSION['array_data'], $index, 1);
    if ($action === 'reset') $_SESSION['array_data'] = ["Apel", "Jeruk", "Mangga"];
    if ($action === 'search' && $value !== '') {
        $_SESSION['array_message'] = in_array($value, $_SESSION['array_data'], true)
            ? "Data \"$value\" ditemukan."
            : "Data \"$value\" tidak ditemukan.";
    }
    header("Location: array.php"); exit;
}
$message = $_SESSION['array_message'] ?? '';
unset($_SESSION['array_message']);
$data = $_SESSION['array_data'];
?>
<!DOCTYPE html>
<html lang="id"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Array - Struktur Data</title><link rel="stylesheet" href="style.css"></head>
<body>
<header><div class="container"><h1>Array</h1><p>Implementasi Struktur Data Linear</p></div></header>
<main class="container">
<a class="back" href="index.php">← Kembali ke Beranda</a>
<section class="panel">
<h2>Simulasi Array</h2>
<p>Array menyimpan beberapa elemen secara berurutan dan setiap elemen memiliki indeks yang dimulai dari 0.</p>
<div class="forms">
<form method="post"><input type="hidden" name="action" value="add"><input name="value" placeholder="Data baru" required><button>Tambah</button></form>
<form method="post"><input type="hidden" name="action" value="search"><input name="value" placeholder="Cari data" required><button>Cari</button></form>
<form method="post"><input type="hidden" name="action" value="delete"><input type="number" name="index" min="0" placeholder="Indeks" required><button class="danger">Hapus</button></form>
<form method="post"><input type="hidden" name="action" value="reset"><button class="secondary">Reset</button></form>
</div>
<?php if ($message): ?><div class="message"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<div class="data-row">
<?php foreach ($data as $i => $item): ?>
<div class="data-box"><small>Indeks <?= $i ?></small><strong><?= htmlspecialchars($item) ?></strong></div>
<?php endforeach; ?>
</div>
<h3>Konsep</h3><p><b>Tambah:</b> elemen masuk ke akhir array. <b>Hapus:</b> elemen pada indeks tertentu dihapus. <b>Cari:</b> PHP memeriksa isi array menggunakan pencarian nilai.</p>
</section>
</main><footer>Array • Nazwa Azzahra • 25012098 • 25M11</footer>
</body></html>