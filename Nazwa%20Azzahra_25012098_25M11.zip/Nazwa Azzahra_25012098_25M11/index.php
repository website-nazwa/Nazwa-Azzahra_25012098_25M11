<?php
$pageTitle = "Struktur Data Linear";
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<header>
    <div class="container">
        <h1>Project Struktur Data Linear</h1>
        <p>Nazwa Azzahra • 25012098 • 25M11</p>
    </div>
</header>
<main class="container">
    <section class="hero">
        <h2>Implementasi Struktur Data Linear</h2>
        <p>Pelajari dan coba langsung cara kerja Array, Linked List, dan Stack melalui halaman interaktif berikut.</p>
    </section>
    <div class="cards">
        <a class="card" href="array.php">
            <span class="number">01</span>
            <h3>Array</h3>
            <p>Menambah, menghapus, dan mencari data berdasarkan indeks.</p>
            <span class="button">Buka Array →</span>
        </a>
        <a class="card" href="linkedlist.php">
            <span class="number">02</span>
            <h3>Linked List</h3>
            <p>Menambahkan dan menghapus node serta melihat hubungan antar-node.</p>
            <span class="button">Buka Linked List →</span>
        </a>
        <a class="card" href="stack.php">
            <span class="number">03</span>
            <h3>Stack</h3>
            <p>Menggunakan konsep LIFO: data terakhir masuk menjadi yang pertama keluar.</p>
            <span class="button">Buka Stack →</span>
        </a>
    </div>
</main>
<footer>Project PHP Struktur Data Linear — Nazwa Azzahra</footer>
</body>
</html>